//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<firebase_app_distribution_ios/FirebaseAppDistributionPlugin.h>)
#import <firebase_app_distribution_ios/FirebaseAppDistributionPlugin.h>
#else
@import firebase_app_distribution_ios;
#endif

#if __has_include(<firebase_core/FLTFirebaseCorePlugin.h>)
#import <firebase_core/FLTFirebaseCorePlugin.h>
#else
@import firebase_core;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FirebaseAppDistributionPlugin registerWithRegistrar:[registry registrarForPlugin:@"FirebaseAppDistributionPlugin"]];
  [FLTFirebaseCorePlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTFirebaseCorePlugin"]];
}

@end
